---
name: python-env-guard
version: 2.1.2
description: 当用户需要执行Python脚本、安装依赖、管理Python项目环境时自动触发。强制使用项目级虚拟环境(.venv)隔离项目操作，依赖管理统一使用uv pip（禁止pip）。Do NOT use when: 非Python任务、用户明确要求使用系统Python执行项目操作（需二次确认）。
---

# Python 环境守卫

> 版本: V2.1.2 | 适用: macOS + Windows | 核心原则: 项目虚拟环境隔离

---

## 使用场景

### 正向触发条件（Do use when）

- 用户需要运行Python脚本
- 用户需要安装/卸载Python依赖
- 用户需要创建或管理Python虚拟环境
- 用户需要检查Python环境状态
- 用户提到 `pip install`、`python运行`、`虚拟环境`、`venv`、`uv` 等关键词

### 负向排除条件（Do NOT use when）

- 用户请求与Python无关的操作（前端开发、数据库管理、系统运维等）
- 用户明确要求使用系统Python执行项目操作（需二次确认）
- 用户请求的是非Python语言的依赖管理（npm、cargo、gem等）

---

## 输入

```yaml
Input:
  task_type:                    # 必填
    type: enum
    values: [run_script, install_deps, manage_env, check_env]
    description: |
      run_script    - 使用.venv解释器运行Python脚本
      install_deps  - 使用uv pip安装依赖到.venv
      manage_env    - 创建/重建/切换虚拟环境
      check_env     - 检查环境健康状态
  script_path: string           # task_type=run_script时必填
  packages: list[string]        # task_type=install_deps时必填
  python_version: string        # 可选，指定Python版本（如"3.12"）
```

## 输出

```yaml
Output:
  result: string                # 执行结果描述
  commands_executed: list       # 实际执行的命令列表（可追溯）
  env_status: object            # 环境状态快照
    fields:
      venv_exists: bool
      python_version: string
      python_path: string
      installed_packages: int
```

---

## 核心硬约束

> 以下约束为最高优先级，违反任何一条均视为严重错误。完整定义见 `references/01-硬约束规则.md`。

| 编号 | 约束 | 正确做法 | 禁止做法 |
|------|------|---------|---------|
| IR-01 | 项目操作必须在.venv中执行 | `.venv/bin/python script.py` | `python script.py` |
| IR-02 | 依赖安装只用uv pip | `uv pip install requests` | `pip install requests` |
| IR-03 | 无.venv时必须先创建 | `uv venv .venv` → 再执行 | 跳过环境检测直接执行 |
| IR-04 | 使用uv venv创建环境 | `uv venv .venv` | `python -m venv .venv` |
| IR-05 | 用完整解释器路径调用 | `.venv/bin/python` | 依赖`source activate` |
| IR-06 | 项目内路径优先用相对路径 | `./data/input.csv` | 绝对路径 |
| IR-07 | uv pip执行前确认.venv可被发现 | 确认.venv存在 | 在无.venv时执行uv pip |

---

## 指令

### STEP 0: 递归式环境检测（从底向上，逐层修复）

> **这是最关键的步骤，不可跳过。每一层失败时，先尝试自动修复，修复失败才提示用户。**

#### 0.0 检测操作系统

```
检测当前操作系统:
  → macOS → 加载 references/02-Mac平台策略.md
  → Windows → 加载 references/03-Windows平台策略.md
```

#### 0.1 检测 uv 是否可用

```bash
uv --version
```

| 结果 | 处理 |
|------|------|
| 输出版本号 | ✅ 可用 → 0.2 |
| 命令不存在 | ❌ 安装uv → 安装后重新检测 → 仍失败 → 提示用户手动处理，暂停 |

安装uv:
```bash
# macOS
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

#### 0.2 检测基础Python是否可用

基础Python是.venv的创建母体，必须可用。

**macOS**:
```bash
/opt/homebrew/bin/python3 --version
```
| 结果 | 处理 |
|------|------|
| 输出版本号 | ✅ 可用 → 0.3 |
| 命令不存在 | → 尝试Intel Mac路径: `/usr/local/bin/python3 --version` |
| 仍不存在 | → 检测Homebrew → 见下方 |

macOS无Python时的修复链:
```
推断版本:
  1. 读取 .python-version（如存在）
  2. 读取 pyproject.toml 中的 requires-python（如存在）
  3. 都没有 → 安装最新版

brew --version
  ├─ 可用 → brew install python@<版本>（如有版本偏好）/ brew install python（无偏好）→ 重新检测Python
  └─ 不可用 → 安装Homebrew:
       /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
       安装成功 → eval "$(/opt/homebrew/bin/brew shellenv)" → brew install python
       安装失败 → 提示用户手动安装Homebrew，暂停
```

**Windows**:
```bash
uv python find
```
| 结果 | 处理 |
|------|------|
| 找到Python | ✅ 可用 → 0.3 |
| 未找到 | → 安装Python → 见下方 |

Windows无Python时的修复:
```
推断版本:
  1. 读取 .python-version（如存在）
  2. 读取 pyproject.toml 中的 requires-python（如存在）
  3. 都没有 → 默认 3.12

安装:
  uv python install <版本>
  安装成功 → 重新检测 → 仍失败 → 提示用户，暂停
```

#### 0.3 多版本判断

检测到多个可用Python时，列出所有版本并提示用户选择:

```
检测到多个Python版本:
  [1] Python 3.12.4  (/opt/homebrew/bin/python3)  ← 推荐
  [2] Python 3.11.9  (/usr/local/bin/python3)
请选择要使用的版本（输入编号，默认1）:
```

仅1个可用Python → 直接使用。

> **AI执行策略**: 若检测到多个版本且无法交互式选择，默认选择版本号最高的Python（除非用户通过 `python_version` 指定了版本）。

#### 0.4 检测/创建 .venv

```
检测项目目录下 .venv 是否存在:
  ├─ 存在 → 验证解释器可用性
  │   ├─ .venv/bin/python --version（Mac）/ .venv\Scripts\python.exe --version（Win）
  │   ├─ 可用 → STEP 1
  │   └─ 不可用 → 删除重建（走下方"不存在"分支）
  │
  └─ 不存在 → 创建:
      ├─ Mac:  uv venv --no-managed-python .venv
      └─ Win:  uv venv .venv
      → 验证解释器 → STEP 1
```

> **Mac使用 `--no-managed-python`**: 防止uv选择自己管理的Python，强制使用Homebrew Python。

---

### STEP 1: 执行用户请求

> **前置条件**: STEP 0 全部通过，.venv存在且解释器可用。

#### run_script — 运行脚本

```bash
# macOS
.venv/bin/python <script_path>

# Windows
.venv\Scripts\python.exe <script_path>
```

#### install_deps — 安装依赖

```bash
uv pip install <package>
```

批量安装:
```bash
uv pip install -r requirements.txt
```

从 pyproject.toml 安装项目:
```bash
uv pip install .                # 安装项目及其依赖
uv pip install ".[dev]"         # 安装项目 + 可选依赖组（如dev）
```

> `uv pip` 命令在 macOS 和 Windows 上**完全一致**，无需区分平台。

#### manage_env — 管理环境

重建虚拟环境（同版本）:
```bash
# macOS
rm -rf .venv && uv venv --no-managed-python .venv && uv pip install -r requirements.txt

# Windows CMD
rmdir /s /q .venv && uv venv .venv && uv pip install -r requirements.txt

# Windows PowerShell
if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }; uv venv .venv && uv pip install -r requirements.txt
```

切换Python版本:
```bash
# macOS（需先通过Homebrew安装目标版本）
brew install python@<版本>
rm -rf .venv && uv venv --python /opt/homebrew/bin/python<版本> --no-managed-python .venv && uv pip install -r requirements.txt

# Windows
uv python install <版本>
rm -rf .venv && uv venv --python <版本> .venv && uv pip install -r requirements.txt
```

#### check_env — 环境健康检查

```bash
# 1. 解释器版本
.venv/bin/python --version        # macOS
.venv\Scripts\python.exe --version  # Windows

# 2. uv可用性
uv --version

# 3. 已安装包
uv pip list
```

---

### STEP 2: 结果输出

按 Output 格式输出:
- `result`: 执行结果描述
- `commands_executed`: 实际执行的命令列表
- `env_status`: 环境状态快照

---

## 双平台命令速查

| 操作 | macOS | Windows | 一致性 |
|------|-------|---------|--------|
| **基础Python来源** | Homebrew | uv python install | ❌ |
| **无Python时** | `brew install python` | `uv python install 3.12` | ❌ |
| **创建.venv** | `uv venv --no-managed-python .venv` | `uv venv .venv` | ❌ |
| **运行脚本** | `.venv/bin/python script.py` | `.venv\Scripts\python.exe script.py` | ❌ |
| **安装依赖** | `uv pip install <pkg>` | `uv pip install <pkg>` | ✅ |
| **卸载依赖** | `uv pip uninstall <pkg>` | `uv pip uninstall <pkg>` | ✅ |
| **导出依赖** | `uv pip freeze` | `uv pip freeze` | ✅ |
| **查看已安装** | `uv pip list` | `uv pip list` | ✅ |
| **安装uv** | `curl ... \| sh` | `powershell ... \| iex` | ❌ |
| **删除.venv** | `rm -rf .venv` | `rmdir /s /q .venv`（CMD）/ `Remove-Item -Recurse -Force .venv`（PS） | ❌ |

---

## 反模式警示

| 禁止行为 | 为什么 | 正确做法 |
|---------|--------|---------|
| `python script.py` | 用基础Python直接运行项目脚本 | `.venv/bin/python script.py` |
| `/opt/homebrew/bin/python3 script.py` | 同上（Mac） | `.venv/bin/python script.py` |
| `C:\Python3x\python.exe script.py` | 同上（Win） | `.venv\Scripts\python.exe script.py` |
| `pip install requests` | 污染基础Python | `uv pip install requests` |
| `python -m pip install` | 同上 | `uv pip install` |
| `python -m venv .venv` | 绕过uv工具链 | `uv venv .venv` |
| `conda install` | 引入非标准依赖管理 | `uv pip install` |
| `uv pip install --system` | 绕过.venv直接安装到系统Python | `uv pip install` |
| 跳过STEP 0直接执行 | .venv可能不存在或损坏 | 每次执行前必检 |

---

## 失败策略

| 场景 | 处理方式 |
|------|---------|
| uv不可用 | 自动安装uv；安装失败 → 提供手动命令，暂停 |
| Mac无Homebrew | 自动安装Homebrew；失败 → 提供手动命令，暂停 |
| Mac无Homebrew Python | `brew install python`；失败 → 提示用户，暂停 |
| Win无Python | `uv python install 3.12`；失败 → 提示用户，暂停 |
| 多个Python版本 | 列出所有版本，提示用户选择 |
| .venv损坏 | 删除重建 |
| 依赖安装冲突 | `uv pip uninstall <冲突包>` → `uv pip install <目标包>`；仍失败 → 报告详情 |
| 用户要求用pip安装 | 拒绝执行，说明必须使用uv pip，提供等效命令 |
| 网络问题（国内） | 提示镜像源: 清华 `https://pypi.tuna.tsinghua.edu.cn/simple`、阿里云 `https://mirrors.aliyun.com/pypi/simple`、豆瓣 `https://pypi.doubanio.com/simple` |

---

## 参考文件索引

| 文件 | 内容 | 加载时机 |
|------|------|---------|
| `references/01-硬约束规则.md` | 7条硬约束完整定义 + 科学依据 | 需要理解约束原理时 |
| `references/02-Mac平台策略.md` | Mac专属: Homebrew、路径、Shell | 检测到macOS时 |
| `references/03-Windows平台策略.md` | Windows专属: 路径、编码、多Python共存 | 检测到Windows时 |
| `references/04-uv工具管理.md` | uv安装/命令/故障排除（跨平台） | uv相关操作时 |
