# 02 - Mac平台策略

> 本文件为 macOS 平台的专属策略。当检测到操作系统为 macOS 时加载。
> **关联参考**: 硬约束完整定义见 `references/01-硬约束规则.md`，uv工具管理见 `references/04-uv工具管理.md`。

---

## 1. 基础Python: Homebrew

### 1.1 为什么是Homebrew

macOS上推荐通过Homebrew安装Python（`/opt/homebrew/bin/python3`），理由:

- **科学管理**: Homebrew管理Python的安装、升级、卸载，不污染系统目录
- **版本灵活**: 可安装任意Python版本（`brew install python@3.12`）
- **社区标准**: Mac开发者的主流Python安装方式
- **虚拟环境母体**: `.venv` 基于Homebrew Python创建，复用其版本

### 1.2 检测Homebrew Python

```bash
# Apple Silicon Mac（优先检测）
/opt/homebrew/bin/python3 --version

# Intel Mac（回退检测）
/usr/local/bin/python3 --version
```

| 结果 | 处理 |
|------|------|
| 任一路径输出版本号 | ✅ 可用，记录为基础Python |
| 两个路径都失败 | ❌ 进入修复流程（§1.3） |

### 1.3 安装Homebrew Python

**前置条件**: Homebrew已安装。未安装时先安装Homebrew。

安装Homebrew:
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

安装后需要将brew加入PATH（Apple Silicon）:
```bash
eval "$(/opt/homebrew/bin/brew shellenv)"
```

安装Python:
```bash
# 安装最新版
brew install python

# 安装指定版本
brew install python@3.12
```

安装后验证:
```bash
/opt/homebrew/bin/python3 --version
```

### 1.4 Homebrew Python升级的影响

Homebrew**大版本升级**Python后（如3.11→3.12），已创建的 `.venv` **不会自动更新**，因为 `.venv/pyvenv.cfg` 中的 `home` 字段指向旧版本路径。

> 小版本升级（如3.12.1→3.12.2）通常不影响.venv可用性。

**处理方式**: 删除并重建 `.venv`
```bash
rm -rf .venv
uv venv --no-managed-python .venv
uv pip install -r requirements.txt
```

---

## 2. 解释器路径规范

### 2.1 虚拟环境解释器

| 项目 | 路径 |
|------|------|
| 解释器 | `.venv/bin/python` |
| pip（存在但不推荐使用） | `.venv/bin/pip` |
| 激活脚本（不推荐使用） | `.venv/bin/activate` |

> `.venv/bin/pip` 是.venv内部的pip，虽然存在，但推荐使用 `uv pip` 替代（更快更准确）。

### 2.2 基础Python（仅用于创建.venv）

| 项目 | 路径 |
|------|------|
| Apple Silicon Mac | `/opt/homebrew/bin/python3` |
| Intel Mac（旧版Homebrew） | `/usr/local/bin/python3` |

---

## 3. 创建.venv的特殊参数

Mac上创建.venv时**必须使用 `--no-managed-python`**:

```bash
uv venv --no-managed-python .venv
```

**为什么**: uv默认优先使用自己管理的Python（通过 `uv python install` 安装的）。加上 `--no-managed-python` 后，uv会忽略自己管理的Python，强制使用系统Python（即Homebrew Python）。这确保了.venv复用Homebrew Python版本。

---

## 4. Mac专属注意事项

### 4.1 Shell差异

macOS默认Shell为Zsh，部分用户使用Bash。对Python操作**无影响**:
- `.venv/bin/python script.py` 在Zsh和Bash中行为一致
- `uv pip install <package>` 在Zsh和Bash中行为一致

### 4.2 文件编码

macOS默认编码为UTF-8，通常无需额外处理。

### 4.3 Apple Silicon兼容性

Apple Silicon (ARM架构) Mac上:
- Homebrew安装的Python原生支持ARM架构
- 如果需要x86架构的Python包，可能需要Rosetta转译
- 大多数常用包已支持ARM，通常无需特殊处理

### 4.4 权限问题

```bash
chmod -R u+w .venv
```

---

## 5. Mac常见问题

### Q: `uv venv` 报错找不到Python

**原因**: Homebrew Python未安装或uv未找到它。

**解决**:
```bash
# 1. 确认Homebrew Python已安装
/opt/homebrew/bin/python3 --version

# 2. 如果未安装
brew install python

# 3. 如果已安装但uv找不到，显式指定
uv venv --python /opt/homebrew/bin/python3 --no-managed-python .venv
```

### Q: `.venv` 创建成功但运行脚本报编码错误

**原因**: 脚本文件包含非UTF-8字符。

**解决**: 在脚本头部添加:
```python
# -*- coding: utf-8 -*-
```

### Q: `brew install python` 后 `python3` 命令仍指向旧版本

**原因**: Shell缓存了旧路径。

**解决**:
```bash
hash -r          # Zsh
rehash           # Bash（部分版本）
```

### Q: 连Homebrew都没有

**解决**: 参见 §1.3 安装Homebrew的命令。需要先有curl（macOS自带）。
