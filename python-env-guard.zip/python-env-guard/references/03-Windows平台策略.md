# 03 - Windows平台策略

> 本文件为 Windows 平台的专属策略。当检测到操作系统为 Windows 时加载。
> **关联参考**: 硬约束完整定义见 `references/01-硬约束规则.md`，uv工具管理见 `references/04-uv工具管理.md`。

---

## 1. 基础Python

### 1.1 来源: uv python install

Windows上通过 `uv python install` 管理Python版本。uv会自动下载并管理指定版本的Python，无需手动从python.org下载。

**优势**: 与uv工具链一体化，版本切换简单，不污染系统PATH。

### 1.2 检测基础Python

```powershell
uv python find
```

| 结果 | 处理 |
|------|------|
| 列出Python版本 | ✅ 可用 |
| 未找到Python | ❌ 安装Python（§1.3） |

### 1.3 安装Python

**必须指定版本**（uv要求）:

```powershell
# 安装默认版本（3.12）
uv python install 3.12

# 安装指定版本
uv python install 3.11
```

**版本推断优先级**（当用户未指定版本时）:
1. 读取 `.python-version` 文件（如存在）
2. 读取 `pyproject.toml` 中的 `requires-python`（如存在）
3. 都没有 → 默认 `3.12`

### 1.4 多Python版本共存

Windows上可能同时存在多个Python来源:

| 来源 | 说明 | 与uv的关系 |
|------|------|-----------|
| uv python install | uv管理的Python | ✅ 推荐 |
| python.org官方安装包 | 传统方式 | ⚠️ 可用但不推荐 |
| Microsoft Store | 应用商店安装 | ⚠️ 某些包可能有兼容问题 |
| Anaconda/Miniconda | 数据科学发行版 | ❌ 不推荐（预装大量包，可能污染.venv） |

> 如果存在多个Python版本，SKILL.md §STEP 0.3 会提示用户选择。

---

## 2. 解释器路径规范

### 2.1 虚拟环境解释器

| 项目 | 路径 |
|------|------|
| 解释器 | `.venv\Scripts\python.exe` |
| pip（存在但不推荐使用） | `.venv\Scripts\pip.exe` |
| 激活脚本（不推荐使用） | `.venv\Scripts\activate.bat` |

### 2.2 路径分隔符

Windows使用 `\` 作为路径分隔符:

```powershell
# CMD / PowerShell
.venv\Scripts\python.exe script.py
```

> 在Git Bash、WSL或MSYS2中，正斜杠 `/` 也有效。但本Skill面向CMD和PowerShell。

---

## 3. Windows专属注意事项

### 3.1 PowerShell vs CMD

| 项目 | CMD | PowerShell |
|------|-----|------------|
| 删除目录 | `rmdir /s /q .venv` | `if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }` |
| 查看Python | `python --version` | `python --version` |
| uv命令 | `uv pip install <pkg>` | `uv pip install <pkg>` |

> `uv pip` 命令在CMD和PowerShell中**完全一致**，无需区分。

### 3.2 文件编码

Windows默认编码为GBK（cp936）。如果脚本包含中文，建议在脚本头部声明:

```python
# -*- coding: utf-8 -*-
```

### 3.3 路径中的空格

如果项目路径包含空格（如 `C:\My Project\`），命令需要用引号包裹:

```powershell
"C:\My Project\.venv\Scripts\python.exe" script.py
```

### 3.4 执行策略

PowerShell可能限制脚本执行。如果遇到相关错误:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

---

## 4. Windows常见问题

### Q: `python` 命令找不到

**原因**: 系统PATH中没有Python。

**解决**: 使用 `uv python install` 安装Python，uv会自动管理路径。无需手动配置PATH。

### Q: `uv pip install` 报权限错误

**原因**: .venv目录权限不足。

**解决**:
```cmd
icacls .venv /grant %USERNAME%:F /T
```

### Q: 安装包时报 `Microsoft Visual C++ 14.0 is required`

**原因**: 某些包需要C编译器。

**解决**: 安装 [Microsoft C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)

### Q: `uv` 命令找不到

**解决**:
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```
